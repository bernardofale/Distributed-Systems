package entities;

public enum OrdinaryThievesStates {
    CONCENTRATION_SITE,
    CRAWLING_INWARDS,
    AT_A_ROOM,
    CRAWLING_OUTWARDS,
    COLLECTION_SITE
}
